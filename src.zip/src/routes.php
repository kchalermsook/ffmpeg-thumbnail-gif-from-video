<?php

use Slim\Http\Request;
use Slim\Http\Response;

// Routes

$app->get('/convert/[{name}]', function (Request $request, Response $response, array $args) {
        $name = $args['name'];
        $videoGif = new Antalaron\VideoGif\VideoGif();
        $videoGif->create('/Users/hideoaki/Downloads/sample.mp4', '/Users/hideoaki/Downloads/sample.gif');	
	die($name);

});

$app->get('/test/[{name}]', function (Request $request, Response $response, array $args) {
    // Sample log message
    $this->logger->info("Slim-Skeleton '/' route");

    // Render index view
    return $this->renderer->render($response, 'index.phtml', $args);
});
